//
//  Contato.swift
//  Promobit
//
//  Created by Master Mac on 06/02/21.
//  Autor : Professor Aécio
//

import UIKit

class Contato: NSObject {
    
    var id = ""
    var createdAt = ""
    var name = ""
    var avatar = ""
    var company = ""
    var email = ""
    var phone = ""
    var website = ""
    var custom_note = ""
    var fotoUIImage : UIImage?
    var maisNovo = false

}
