//
//  AddContatoMsgConfirmViewControllerHandlers.swift
//  Promobit
//
//  Created by Master Mac on 07/02/21.
//

import Foundation
import UIKit

extension AddContatoMsgConfirmViewController {
    
    func setupView(){
        voltarButtonOutlet.layer.borderColor = UIColor.rgb(red: 255, green: 255, blue: 255).cgColor // cor da borda do botão
    }
    
}
