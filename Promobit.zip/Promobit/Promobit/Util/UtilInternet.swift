//
//  UtilInternet.swift
//  Promobit
//
//  Created by Master Mac on 06/02/21.
//  Autor : Professor Aécio
//

import UIKit

class UtilInternet: NSObject {

    // Utilitário cuja função é relatar se o app tem conexão
    var possuiConexao : Bool = true
    
}
