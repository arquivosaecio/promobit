//
//  ViewController.swift
//  Promobit
//
//  Created by Master Mac on 06/02/21.
//

import UIKit

class ViewController: UIViewController {
    
    var window: UIWindow?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

